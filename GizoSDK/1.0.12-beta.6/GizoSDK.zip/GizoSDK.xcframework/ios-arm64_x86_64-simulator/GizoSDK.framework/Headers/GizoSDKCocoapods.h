//
//  GizoSDKCocoapods.h
//  GizoSDKCocoapods
//
//  Created by Meysam Farmani on 4/19/24.
//

#import <Foundation/Foundation.h>

//! Project version number for GizoSDKCocoapods.
FOUNDATION_EXPORT double GizoSDKCocoapodsVersionNumber;

//! Project version string for GizoSDKCocoapods.
FOUNDATION_EXPORT const unsigned char GizoSDKCocoapodsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GizoSDKCocoapods/PublicHeader.h>


