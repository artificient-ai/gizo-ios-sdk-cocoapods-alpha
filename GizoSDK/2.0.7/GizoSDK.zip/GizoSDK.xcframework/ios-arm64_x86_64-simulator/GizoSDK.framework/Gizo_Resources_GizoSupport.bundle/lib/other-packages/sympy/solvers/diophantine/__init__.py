from .diophantine import diophantine, classify_diop, diop_solve

__all__ = [
    'diophantine', 'classify_diop', 'diop_solve'
]
